//$(document).ready(function() {
    /*var datTable = $('#datatable');
    datTable.DataTable({
        'order': [[ 1, 'desc' ]],
        'aoColumns': [
            null,
            {
                'bSortable': false
            }
        ]
    });*/
    
    $('#example').DataTable();
    
    /*$('#table').DataTable( {
        "scrollY":        "20px",
        "scrollCollapse": true,
        "paging":         false
    } );*/
//} );